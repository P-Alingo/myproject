<?php
require_once("connect.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patientSSN = $_POST['ssn'];
    $newName = $_POST['name'];
    $newEmail = $_POST['email'];
    $newPassword = $_POST['password'];
    $newAddress = $_POST['address'];
    $newDateOfBirth = $_POST['dob'];
    
    // Perform edit operation using UPDATE statement
    $update_query = "UPDATE patient SET full_name='$newName', email='$newEmail', password='$newPassword', address='$newAddress', date_of_birth='$newDateOfBirth' WHERE SSN='$patientSSN'";
    
    if ($conn->query($update_query) === TRUE) {
        // Redirect back to patientdetails.php
        header("Location: patientdetails.php");
        exit();
    } else {
        echo "Error updating patient record: " . $conn->error;
    }
} else {
    // Check if SSN parameter is present in the URL
    if (isset($_GET['ssn'])) {
        $patientSSN = $_GET['ssn'];

        // Fetch patient details by SSN
        $fetch_query = "SELECT * FROM patient WHERE SSN='$patientSSN'";
        $result = $conn->query($fetch_query);
        $row = $result->fetch_assoc();

        if ($row) {
            // Display form for editing patient details
            echo "
            <h2>Edit Patient Details</h2>
            <form action='' method='POST'>
                <input type='hidden' name='ssn' value='{$row['SSN']}' required>
                <label for='name'>Name:</label>
                <input type='text' name='name' value='{$row['full_name']}' required><br>
                <label for='email'>Email:</label>
                <input type='email' name='email' value='{$row['email']}' required><br>
                <label for='password'>Password:</label>
                <input type='password' name='password' value='{$row['password']}' required><br>
                <label for='address'>Address:</label>
                <input type='text' name='address' value='{$row['address']}' required><br>
                <label for='dob'>DateOfBirth:</label>
                <input type='date' name='dob' value='{$row['date_of_birth']}'><br>
                <input type='submit' value='Update'>
            </form>
            ";
        } else {
            echo "Patient not found.";
        }
    } else {
        echo "Invalid request.";
    }
}

$conn->close();
?>
