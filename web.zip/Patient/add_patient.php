<?php
require_once("connect.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = $_POST['full_name'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phoneNumber = $_POST['phone_number'];
    $address = $_POST['address'];
    $dateOfBirth = $_POST['date_of_birth'];
    
    // Prepare and bind the SQL statement
    $stmt = $conn->prepare("INSERT INTO patient (full_name, gender, email, password, phone_number, address, date_of_birth) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $fullName, $gender, $email, $password, $phoneNumber, $address, $dateOfBirth);
    
    if ($stmt->execute()) {
        // Redirect to add_patient.php
        header("Location: add_patient.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    
    $stmt->close();
} else {
    // Display form for adding a patient
    echo "
    <h2>Add Patient</h2>
    <form action='' method='POST'>
        <label for='full_name'>Full Name:</label>
        <input type='text' name='full_name' required><br>
        <label for='gender'>Gender:</label>
        <input type='text' name='gender' required><br>
        <label for='email'>Email:</label>
        <input type='email' name='email' required><br>
        <label for='password'>Password:</label>
        <input type='password' name='password' required><br>
        <label for='phone_number'>Phone Number:</label>
        <input type='text' name='phone_number' required><br>
        <label for='address'>Address:</label>
        <input type='text' name='address' required><br>
        <label for='date_of_birth'>Date of Birth:</label>
        <input type='date' name='date_of_birth'><br>
        <input type='submit' value='Add Patient'>
    </form>
    ";
}

$conn->close();
?>
