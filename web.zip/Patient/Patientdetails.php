<?php
require_once("connect.php");

// Pagination Variables
$records_per_page = 10;
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $records_per_page;

// Fetch total number of records
$total_records_query = "SELECT COUNT(*) AS total FROM patient";
$total_records_result = $conn->query($total_records_query);
$total_records = $total_records_result->fetch_assoc()['total'];

// Calculate total pages
$total_pages = ceil($total_records / $records_per_page);

// Edit and Delete operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['edit'])) {
        // Fetch specific patient details to edit
        $patientSSN = $_POST['edit'];
        
        // Redirect to the edit page with patient SSN as a parameter
        header("Location: edit_patient.php?ssn=" . urlencode($patientSSN));
        exit();
    } elseif (isset($_POST['delete'])) {
        // Delete patient record from the database
        $patientSSN = $_POST['delete'];
        
        // Perform delete operation
        $delete_query = "DELETE FROM patient WHERE SSN = '$patientSSN'";
        $delete_result = $conn->query($delete_query);
        
        if ($delete_result) {
            echo "Patient with SSN: $patientSSN deleted successfully.";
        } else {
            echo "Failed to delete patient with SSN: $patientSSN.";
        }
    }
}

// Fetch patient details with pagination
$fetch_query = "SELECT `SSN`, `full_name`, `gender`, `email`, `password`, `phone_number`, `address`, `date_of_birth` FROM patient LIMIT $offset, $records_per_page";
$result = $conn->query($fetch_query);

// Display patient table
echo "
<table>
    <tr>
        <th>Full Name</th>
        <th>Gender</th>
        <th>Email</th>
        <th>Password</th>
        <th>Phone Number</th>
        <th>Address</th>
        <th>Date of Birth</th>
        <th>Action</th>
    </tr>
";
while ($row = $result->fetch_assoc()) {
    echo "
    <tr>
        <td>{$row['full_name']}</td>
        <td>{$row['gender']}</td>
        <td>{$row['email']}</td>
        <td>{$row['password']}</td>
        <td>{$row['phone_number']}</td>
        <td>{$row['address']}</td>
        <td>";
    if (!empty($row['date_of_birth'])) {
        echo $row['date_of_birth'];
    } else {
        echo "N/A";
    }
    echo "</td>
        <td>
            <form action='' method='POST'>
                <button type='submit' name='edit' value='{$row['SSN']}'>Edit</button>
                <button type='submit' name='delete' value='{$row['SSN']}'>Delete</button>
            </form>
        </td>
    </tr>
    ";
}
echo "</table>";

// Pagination Links
echo "<div class='pagination'>";
if ($total_pages > 1) {
    for ($i = 1; $i <= $total_pages; $i++) {
        echo "<a href='?page={$i}'>{$i}</a>";
    }
}
echo "</div>";

$conn->close();
?>
