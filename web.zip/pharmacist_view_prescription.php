<?php
require_once("connection.php");

// Start the session
session_start();

// Check if the 'email' key is set in the session
if (isset($_SESSION['email'])) {
  // Retrieve the pharmacist's email from the session
  $email = $_SESSION['email'];

  // Get the pharmacist's full name
  $query = "SELECT full_name FROM pharmacist WHERE email = '$email'";
  $result = $conn->query($query);

  if ($result !== false && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $fullName = $row['full_name'];

    // Display the pharmacist's full name
    echo "<h2>Welcome, $fullName</h2>";
  }
}

// Fetch prescription data from view_prescriptions
$query = "SELECT prescription_id, drug_id, patient_SSN, patient_full_name, doctor_SSN, doctor_full_name, trace_name, date, dosage, quantity, price FROM view_prescription";
$result = $conn->query($query);

if ($result !== false && $result->num_rows > 0) {
  echo "<h1>All Prescriptions</h1>";
  echo "<table>";
  echo "<tr><th>Prescription ID</th><th>Drug ID</th><th>Patient SSN</th><th>Patient Full Name</th><th>Doctor SSN</th><th>Doctor Full Name</th><th>Trace Name</th><th>Date</th><th>Dosage</th><th>Quantity</th><th>Price</th></tr>";

  while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $row['prescription_id'] . "</td>";
    echo "<td>" . $row['drug_id'] . "</td>";
    echo "<td>" . $row['patient_SSN'] . "</td>";
    echo "<td>" . $row['patient_full_name'] . "</td>";
    echo "<td>" . $row['doctor_SSN'] . "</td>";
    echo "<td>" . $row['doctor_full_name'] . "</td>";
    echo "<td>" . $row['trace_name'] . "</td>";
    echo "<td>" . $row['date'] . "</td>";
    echo "<td>" . $row['dosage'] . "</td>";
    echo "<td>" . $row['quantity'] . "</td>";
    echo "<td>" . $row['price'] . "</td>";
    echo "</tr>";
  }

  echo "</table>";

  // Display the back button
  echo "<form method='GET' action='pharmacistpage.php'>";
  echo "<input type='submit' value='Back'>";
  echo "</form>";
} else {
  echo "No prescriptions found.";
}

$conn->close();
?>
