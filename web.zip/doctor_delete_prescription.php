<?php
require_once("connection.php");

// Start the session
session_start();

// Check if the 'email' key is set in the session
if (isset($_SESSION['email'])) {
    // Retrieve the doctor's email from the session
    $email = $_SESSION['email'];

    // Retrieve the doctor's details from the database
    $doctorQuery = "SELECT * FROM doctor WHERE email='$email'";
    $doctorResult = $conn->query($doctorQuery);

    if ($doctorResult->num_rows > 0) {
        // Fetch the doctor's details
        $doctorRow = $doctorResult->fetch_assoc();
        $doctorSSN = $doctorRow['SSN']; // Retrieve the doctor's SSN

        // Check if the form was submitted and the prescription ID is set
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['prescription_id'])) {
            // Retrieve the prescription ID from the form
            $prescriptionID = $_POST['prescription_id'];

            // Delete the prescription from the database
            $deleteQuery = "DELETE FROM Prescription WHERE prescription_id='$prescriptionID' AND doctor_SSN='$doctorSSN'";

            if ($conn->query($deleteQuery) === TRUE) {
                // Prescription deleted successfully, redirect to doctor_view_prescription.php
                header("Location: doctor_view_prescription.php");
                exit();
            } else {
                echo "Error deleting prescription: " . $conn->error;
            }
        } else {
            echo "Invalid request.";
        }
    } else {
        echo "Doctor not found.";
    }
} else {
    echo "Invalid session. Please login again.";
}

$conn->close();
?>


