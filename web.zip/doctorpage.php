<?php
require_once("connection.php");

// Start the session
session_start();

// Check if the 'email' key is set in the session
if (isset($_SESSION['email'])) {
  // Retrieve the doctor's email from the session
  $email = $_SESSION['email'];

  // Retrieve the doctor's details from the database
  $query = "SELECT * FROM doctor WHERE email='$email'";
  $result = $conn->query($query);

  if ($result->num_rows > 0) {
    // Retrieve the doctor's full name from the database
    $row = $result->fetch_assoc();
    $full_name = $row['full_name'];
  } else {
    // If the doctor's details are not found, redirect to the login page
    header("Location: Doctor_login.php");
    exit();
  }
} else {
  // If the 'email' key is not set in the session, redirect to the login page
  header("Location: Doctor_login.php");
  exit();
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Doctor Page</title>
  <style>
    body {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      justify-content: flex-start;
      height: 100vh;
      background-color: #f2f2f2;
      margin: 0;
      padding: 20px;
      font-family: Arial, sans-serif;
    }

    h1 {
      text-align: center;
      color: #333;
      margin-bottom: 20px;
    }

    div {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
    }

    button {
      display: block;
      margin-bottom: 10px;
      background-color: #4c56af;
      color: white;
      padding: 10px 20px;
      font-size: 16px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    button:hover {
      background-color: #7445a0;
    }
  </style>
</head>
<body>
    
<div class="user-info">
    Welcome, <?php echo $full_name; ?>!
  </div>
  
    <button onclick="window.location.href='Doctor_profile.php'">Profile</button>
    <button onclick="window.location.href='doctor_appointment.php'">Patient Appointments</button>
    <button onclick="window.location.href='Doctor_prescription.php'">Prescription</button>
    <button onclick="window.location.href='mainpage.html'">Logout</button>
  </div>
</body>
</html>

<style>body {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  height: 100vh;
  background-color: #f2f2f2;
  margin: 0;
  padding: 20px;
  font-family: Arial, sans-serif;
}

h1 {
  text-align: center;
  color: #333;
  margin-bottom: 20px;
}

div {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

button {
  display: block;
  margin-bottom: 10px;
  background-color: #4c56af;
  color: white;
  padding: 10px 20px;
  font-size: 16px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #7445a0;
}
</style>