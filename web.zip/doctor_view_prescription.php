<?php
require_once("connection.php");

// Start the session
session_start();

// Check if the 'email' key is set in the session
if (isset($_SESSION['email'])) {
    // Retrieve the doctor's email from the session
    $email = $_SESSION['email'];
    $fullName = $_SESSION['full_name'];

    echo "<div class='user-info'>";
    echo "<h2>$fullName</h2>";
    echo "</div>";

    // Retrieve the doctor's details from the database
    $doctorQuery = "SELECT * FROM doctor WHERE email='$email'";
    $doctorResult = $conn->query($doctorQuery);

    if ($doctorResult->num_rows > 0) {
        // Fetch the doctor's details
        $doctorRow = $doctorResult->fetch_assoc();
        $doctorSSN = $doctorRow['SSN']; // Retrieve the doctor's SSN

        // Retrieve the list of prescriptions created by the doctor
        $prescriptionQuery = "SELECT * FROM Prescription WHERE doctor_SSN='$doctorSSN'";
        $prescriptionResult = $conn->query($prescriptionQuery);

        // Check if there are prescriptions available
        if ($prescriptionResult->num_rows > 0) {
            echo "<h1>Doctor Prescriptions</h1>";

            while ($prescriptionRow = $prescriptionResult->fetch_assoc()) {
                echo "<p>Prescription ID: " . $prescriptionRow['prescription_id'] . "</p>";
                echo "<p>Patient SSN: " . $prescriptionRow['patient_SSN'] . "</p>";
                echo "<p>Patient Full Name: " . $prescriptionRow['patient_full_name'] . "</p>";
                echo "<p>Trace Name: " . $prescriptionRow['trace_name'] . "</p>";
                echo "<p>Date: " . $prescriptionRow['date'] . "</p>";
                echo "<p>Dosage: " . $prescriptionRow['dosage'] . "</p>";
                echo "<p>Quantity: " . $prescriptionRow['quantity'] . "</p>";

                // Edit button
                echo "<form method='post' action='doctor_update_prescription.php'>";
                echo "<input type='hidden' name='prescription_id' value='" . $prescriptionRow['prescription_id'] . "'>";
                echo "<input type='submit' value='Edit Prescription'>";
                echo "</form>";

                // Delete button
                echo "<form method='post' action='doctor_delete_prescription.php'>";
                echo "<input type='hidden' name='prescription_id' value='" . $prescriptionRow['prescription_id'] . "'>";
                echo "<input type='submit' value='Delete Prescription'>";
                echo "</form>";

                echo "<hr>";
            }

            // Back button
            echo "<div class='back-button'>";
            echo "<button onclick=\"window.location.href = 'Doctor_prescription.php';\">Back</button>";
            echo "</div>";
        } else {
            echo "No prescriptions found.";
        }
    } else {
        echo "Doctor not found.";
    }
} else {
    echo "Invalid session. Please login again.";
}

$conn->close();
?>
