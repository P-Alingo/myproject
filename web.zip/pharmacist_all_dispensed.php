<?php
require_once("connection.php");

// Start the session
session_start();

// Check if the 'email' key is set in the session
if (isset($_SESSION['email'])) {
  // Retrieve the pharmacist's email from the session
  $email = $_SESSION['email'];

  // Get the pharmacist's full name
  $query = "SELECT full_name FROM pharmacist WHERE email = '$email'";
  $result = $conn->query($query);

  if ($result !== false && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $fullName = $row['full_name'];

    // Display the pharmacist's full name
    echo "<h2>Welcome, $fullName</h2>";
  } else {
    echo "Pharmacist not found.";
  }
} else {
  echo "Invalid session. Please login again.";
}

// Fetch all dispensed drugs from the view_drug_dispense table
$query = "SELECT * FROM view_drug_dispense";
$result = $conn->query($query);

if ($result !== false && $result->num_rows > 0) {
  echo "<h1>Dispensed Drugs</h1>";
  echo "<table>";
  echo "<tr><th>Dispense ID</th><th>Prescription ID</th><th>Patient SSN</th><th>Patient Full Name</th><th>Doctor SSN</th><th>Doctor Full Name</th><th>Drug ID</th><th>Trace Name</th><th>Dosage</th><th>Quantity</th><th>Price</th><th>Date</th><th>Actions</th></tr>";

  while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $row['dispense_id'] . "</td>";
    echo "<td>" . $row['prescription_id'] . "</td>";
    echo "<td>" . $row['patient_SSN'] . "</td>";
    echo "<td>" . $row['patient_full_name'] . "</td>";
    echo "<td>" . $row['doctor_SSN'] . "</td>";
    echo "<td>" . $row['doctor_full_name'] . "</td>";
    echo "<td>" . $row['drug_id'] . "</td>";
    echo "<td>" . $row['trace_name'] . "</td>";
    echo "<td>" . $row['dosage'] . "</td>";
    echo "<td>" . $row['quantity'] . "</td>";
    echo "<td>" . $row['price'] . "</td>";
    echo "<td>" . $row['date'] . "</td>";
    echo "<td>";
    echo "<a href=\"pharmacist_edit_dispense.php?dispense_id=" . $row['dispense_id'] . "\">Edit</a> | ";
    echo "<a href=\"pharmacist_delete_dispense.php?dispense_id=" . $row['dispense_id'] . "\">Delete</a>";
    echo "</td>";
    echo "</tr>";
  }

  echo "</table>";
  echo "<form method='GET' action='pharmacistpage.php'>";
  echo "<input type='submit' value='Back'>";
  echo "</form>";
} else {
  echo "No dispensed drugs found.";
}

$conn->close();
?>

