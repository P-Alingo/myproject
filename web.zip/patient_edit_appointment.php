<?php
require_once("connection.php");

// Start the session
session_start();

// Check if the appointmentID is set
if (isset($_POST['appointmentID'])) {
  // Retrieve the appointmentID from the form
  $appointmentID = $_POST['appointmentID'];
  
  // Check if the full_name session variable is set
  if (isset($_SESSION['full_name'])) {
    $fullName = $_SESSION['full_name'];

    // Retrieve the appointment details from the database
    $appointmentQuery = "SELECT * FROM appointment WHERE appointment_id='$appointmentID'";
    $appointmentResult = $conn->query($appointmentQuery);

    if ($appointmentResult->num_rows > 0) {
      echo "<style>
              .user-info {
                font-weight: bold;
                margin-bottom: 20px;
              }
              h1 {
                font-size: 24px;
                margin-bottom: 10px;
              }
              label {
                display: block;
                margin-bottom: 5px;
              }
              input[type='date'],
              input[type='time'],
              textarea {
                margin-bottom: 10px;
                padding: 8px;
                border-radius: 4px;
                border: 1px solid #ccc;
              }
              input[type='submit'] {
                padding: 8px 16px;
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 4px;
                cursor: pointer;
              }
              button {
                display: inline-block;
                padding: 8px 16px;
                background-color: #4CAF50;
                color: white;
                text-decoration: none;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                margin-top: 10px;
              }
              button a {
                color: white;
                text-decoration: none;
              }
            </style>";

      echo "<div class='user-info'>";
      echo "Welcome, $fullName!";
      echo "</div>";

      // Fetch the appointment details
      $appointmentRow = $appointmentResult->fetch_assoc();
      $appointmentDate = $appointmentRow['appointment_date'];
      $appointmentTime = $appointmentRow['appointment_time'];
      $appointmentPurpose = $appointmentRow['appointment_purpose'];

      // Display the edit appointment form
      echo "<h1>Edit Appointment</h1>";
      echo "<form method='POST' action='patient_update_appointment.php'>";
      echo "<input type='hidden' name='appointmentID' value='$appointmentID'>";
      echo "<label for='appointmentDate'>Appointment Date:</label>";
      echo "<input type='date' id='appointmentDate' name='appointmentDate' value='$appointmentDate' required><br><br>";
      echo "<label for='appointmentTime'>Appointment Time:</label>";
      echo "<input type='time' id='appointmentTime' name='appointmentTime' value='$appointmentTime' required><br><br>";
      echo "<label for='appointmentPurpose'>Appointment Purpose:</label>";
      echo "<textarea id='appointmentPurpose' name='appointmentPurpose' required>$appointmentPurpose</textarea><br><br>";
      echo "<input type='submit' value='Update Appointment'>";
      echo "</form>";

      // Add a back button
      echo "<button><a href='patient_view_appointments.php'>Back</a></button>";
    } else {
      echo "Appointment not found.";
    }
  } else {
    echo "Invalid session. Please login again.";
  }
} else {
  echo "Invalid request.";
}

$conn->close();
?>

