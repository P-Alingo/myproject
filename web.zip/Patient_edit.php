<?php
require_once("connection.php");

// Start the session
session_start();

// Check if the 'email' key is set in the session
if (isset($_SESSION['email'])) {
  // Retrieve the patient's email from the session
  $sessionEmail = $_SESSION['email'];
  $fullName = $_SESSION['full_name'];

  // Retrieve the patient's information from the database using their email
  $patientQuery = "SELECT * FROM patient WHERE email='$sessionEmail'";
  $patientResult = $conn->query($patientQuery);

  if ($patientResult->num_rows > 0) {
    // Fetch the patient's information
    $patientRow = $patientResult->fetch_assoc();
    $fullName = $patientRow['full_name'];
    $gender = $patientRow['gender'];
    $email = $patientRow['email'];
    $password = $patientRow['PASSWORD'];
    $dateOfBirth = $patientRow['date_of_birth'];
    $age = $patientRow['age'];
    $phoneNumber = $patientRow['phone_number'];
    $address = $patientRow['address'];

    // Display the edit form
    echo "<div class='user-info'>";
    echo "$fullName";
    echo "</div>";
    echo "<html>";
    echo "<head>";
    echo "<style>";
    echo "h1 {
            font-size: 24px;
            margin-bottom: 10px;
          }
          form {
            margin-top: 20px;
          }
          label {
            display: block;
            margin-bottom: 5px;
          }
          input[type='text'],
          input[type='email'],
          input[type='password'],
          input[type='date'],
          input[type='number'],
          input[type='tel'],
          textarea {
            margin-bottom: 10px;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ccc;
          }
          input[type='submit'] {
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
          }";
    echo "</style>";
    echo "</head>";
    echo "<body>";
    echo "<h1>Edit Patient Information</h1>";
    echo "<form method='POST' action='patient_update.php'>";
    echo "<label for='fullName'>Full Name:</label>";
    echo "<input type='text' id='fullName' name='fullName' value='$fullName' required><br>";
    echo "<label for='gender'>Gender:</label>";
    echo "<select id='gender' name='gender' required>";
    echo "<option value='Male' " . ($gender === 'Male' ? 'selected' : '') . ">Male</option>";
    echo "<option value='Female' " . ($gender === 'Female' ? 'selected' : '') . ">Female</option>";
    echo "</select><br>";
    echo "<label for='email'>Email:</label>";
    echo "<input type='email' id='email' name='email' value='$email' required><br>";
    echo "<label for='password'>Password:</label>";
    echo "<input type='password' id='password' name='password' value='$password' required><br>";
    echo "<label for='dateOfBirth'>Date of Birth:</label>";
    echo "<input type='date' id='dateOfBirth' name='dateOfBirth' value='$dateOfBirth' required><br>";
    echo "<label for='age'>Age:</label>";
    echo "<input type='number' id='age' name='age' value='$age' required><br>";
    echo "<label for='phoneNumber'>Phone Number:</label>";
    echo "<input type='tel' id='phoneNumber' name='phoneNumber' value='$phoneNumber' required><br>";
    echo "<label for='address'>Address:</label>";
    echo "<textarea id='address' name='address' required>$address</textarea><br>";
    echo "<input type='submit' value='Update Information'>";
    echo "<button><a href='Patient_profile.php'>Back</a></button>";
    echo "</form>";
    echo "</body>";
    echo "</html>";
    
  } else {
    echo "Patient not found.";
  }
} else {
  echo "Invalid session. Please login again.";
}

$conn->close();
?>

