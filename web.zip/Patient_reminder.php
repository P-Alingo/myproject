<?php
require_once("connection.php");

// Start the session
session_start();

// Check if the 'email' key is set in the session
if (isset($_SESSION['email'])) {
  // Retrieve the patient's email from the session
  $email = $_SESSION['email'];

  // Retrieve the patient's SSN from the database using their email
  $patientQuery = "SELECT SSN FROM patient WHERE email='$email'";
  $patientResult = $conn->query($patientQuery);

  // Check if the 'full_name' session variable is set
  if (isset($_SESSION['full_name'])) {
    // Retrieve the patient's full name from the session
    $full_name = $_SESSION['full_name'];

    // Display the welcome message
    echo "<div class='user-info'>";
    echo "$full_name";
    echo "</div>";

    if ($patientResult->num_rows > 0) {
      $patientRow = $patientResult->fetch_assoc();
      $patientSSN = $patientRow['SSN'];

      // Check if the form is submitted
      if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve the reminder details from the form
        $details = $_POST['details'];
        $date = $_POST['date'];
        $time = $_POST['time'];

        // Insert the reminder into the database
        $insertQuery = "INSERT INTO Reminder (patient_SSN, details, date, time) VALUES ('$patientSSN', '$details', '$date', '$time')";
        if ($conn->query($insertQuery) === TRUE) {
         
          // Display a notification on the user's computer screen
          echo "<script>
                  if ('Notification' in window) {
                    if (Notification.permission === 'granted') {
                      new Notification('Reminder Created', { body: 'Your reminder has been successfully created.' });
                    } else if (Notification.permission !== 'denied') {
                      Notification.requestPermission().then(function (permission) {
                        if (permission === 'granted') {
                          new Notification('Reminder Created', { body: 'Your reminder has been successfully created.' });
                        }
                      });
                    }
                  }
               </script>";
        } else {
          echo "Error creating reminder: " . $conn->error;
        }
      }

      // Display the reminder form
      echo "<style>
              .user-info {
                font-weight: bold;
                margin-bottom: 20px;
              }
              h1 {
                font-size: 24px;
                margin-bottom: 10px;
              }
              label {
                display: block;
                margin-bottom: 5px;
              }
              input[type='text'],
              input[type='date'],
              input[type='time'],
              input[type='submit'] {
                margin-bottom: 10px;
                padding: 8px;
                border-radius: 4px;
                border: 1px solid #ccc;
              }
              input[type='submit'] {
                background-color: #4CAF50;
                color: white;
                cursor: pointer;
              }
              button {
                display: inline-block;
                padding: 8px 16px;
                background-color: indigo;
                color: white;
                text-decoration: none;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                margin-right: 10px;
              }
              a {
                color: white;
                text-decoration: none;
              }
            </style>";

      echo "<h1>Create Reminder</h1>";
      echo "<form method=\"POST\" action=\"Patient_reminder.php\">";
      echo "<label for=\"details\">Details:</label>";
      echo "<input type=\"text\" id=\"details\" name=\"details\" required><br>";
      echo "<label for=\"date\">Date:</label>";
      echo "<input type=\"date\" id=\"date\" name=\"date\" required><br>";
      echo "<label for=\"time\">Time:</label>";
      echo "<input type=\"time\" id=\"time\" name=\"time\" required><br>";
      echo "<input type=\"submit\" value=\"Create Reminder\">";
      echo "</form>";

      // Add a "View Details" button
      echo "<button><a href=\"view_reminders.php\">View Details</a></button>";
      // Add a back button
      echo "<button><a href=\"patientpage.php\">Back</a></button>";
    } else {
      echo "Patient not found.";
    }
  } else {
    echo "Invalid session. Please login again.";
  }
}

$conn->close();
?>
