<?php
require_once("connection.php");

// Start the session
session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Retrieve the appointment ID from the form
  $appointmentID = $_POST['appointment_id'];
  $fullName = $_SESSION['full_name'];


  // Retrieve the appointment details from the database
  $appointmentQuery = "SELECT * FROM appointment WHERE appointment_id='$appointmentID'";
  $appointmentResult = $conn->query($appointmentQuery);

  if ($appointmentResult->num_rows > 0) {
    // Fetch the appointment details
    $appointmentRow = $appointmentResult->fetch_assoc();
    $appointmentDate = $appointmentRow['appointment_date'];
    $appointmentTime = $appointmentRow['appointment_time'];
    $patientSSN = $appointmentRow['patient_SSN'];

    // Retrieve the patient's details from the database
    $patientQuery = "SELECT * FROM patient WHERE SSN='$patientSSN'";
    $patientResult = $conn->query($patientQuery);

    if ($patientResult->num_rows > 0) {
      echo "<div class='user-info'>";
      echo "<h2>$fullName</h2>";
      echo "</div>";
      // Fetch the patient's detail
      $patientRow = $patientResult->fetch_assoc();
      $patientFullName = $patientRow['full_name'];

      // Display the edit appointment form
     
      echo "<h1>Edit Appointment</h1>";
      echo "<form method='POST' action='doctor_update_appointment.php'>";
      echo "<input type='hidden' name='appointment_id' value='$appointmentID'>";
      echo "<label for='patient'>Patient:</label>";
      echo "<input type='text' id='patient' name='patient' value='$patientFullName' readonly><br><br>";
      echo "<label for='date'>Date:</label>";
      echo "<input type='date' id='date' name='date' value='$appointmentDate' required><br><br>";
      echo "<label for='time'>Time:</label>";
      echo "<input type='time' id='time' name='time' value='$appointmentTime' required><br><br>";
      echo "<input type='submit' value='Update Appointment'>";
      echo "</form>";

      // Back button
      echo "<button class='back-button' onclick='goBack()'>Back</button>";
      echo "<script>";
      echo "function goBack() {";
      echo "  window.location.href = 'doctor_view_appointments.php';";
      echo "}";
      echo "</script>";
    } else {
      echo "Patient not found.";
    }
  } else {
    echo "Appointment not found.";
  }
} else {
  echo "Invalid request.";
}

$conn->close();
?>

<style>
.user-info {
  text-align: center;
  margin-bottom: 20px;
}

.user-info h2 {
  color: #333;
}

h1 {
  text-align: center;
  color: #333;
  margin-bottom: 10px;
}

label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
  color: #333;
}

input[type="text"],
input[type="date"],
input[type="time"] {
  width: 200px;
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
  margin-bottom: 10px;
}

input[type="submit"],
button {
  padding: 8px 12px;
  background-color: #333;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type="submit"]:hover,
button:hover {
  background-color: #555;
}

.back-button {
  margin-top: 20px;
  text-align: left;
}

</style>