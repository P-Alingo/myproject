<?php
require_once("connection.php");

// Start the session
session_start();

// Check if the 'email' key is set in the session
if (isset($_SESSION['email'])) {
  // Retrieve the patient's email from the session
  $email = $_SESSION['email'];

  if (isset($_SESSION['full_name'])) {
    // Retrieve the patient's full name from the session
    $fullName = $_SESSION['full_name'];
  } else {
    // If the 'fullName' session variable is not set, redirect to the login page
    header("Location: Patient_login.html");
    exit();
  }

  // Check if the form is submitted
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the appointment details from the form
    $appointmentDate = $_POST['appointmentDate'];
    $appointmentTime = $_POST['appointmentTime'];
    $appointmentPurpose = $_POST['appointmentPurpose'];
    $doctorSSN = $_POST['doctorSelection'];

    // Retrieve the patient's SSN and full name from the database using their email
    $patientQuery = "SELECT SSN FROM patient WHERE email='$email'";
    $patientResult = $conn->query($patientQuery);

    if ($patientResult->num_rows > 0) {
      $patientRow = $patientResult->fetch_assoc();
      $patientSSN = $patientRow['SSN'];

      // Retrieve the selected doctor's full name from the database
      $doctorQuery = "SELECT full_name FROM doctor WHERE SSN='$doctorSSN'";
      $doctorResult = $conn->query($doctorQuery);

      if ($doctorResult->num_rows > 0) {
        $doctorRow = $doctorResult->fetch_assoc();
        $doctorFullName = $doctorRow['full_name'];

        // Insert the appointment into the database
        $insertQuery = "INSERT INTO appointment (patient_SSN, patient_full_name, doctor_SSN, doctor_full_name, appointment_date, appointment_time, appointment_purpose, appointment_status) 
                        VALUES ('$patientSSN', '$fullName', '$doctorSSN', '$doctorFullName', '$appointmentDate', '$appointmentTime', '$appointmentPurpose', 'Scheduled')";
        
        if ($conn->query($insertQuery) === TRUE) {
          echo "Appointment scheduled successfully.";
        } else {
          echo "Error scheduling appointment: " . $conn->error;
        }
      } else {
        echo "Doctor not found.";
      }
    } else {
      echo "Patient not found.";
    }
  }

  // Retrieve the available doctors from the database
  $query = "SELECT SSN, full_name, specialization FROM doctor";
  $result = $conn->query($query);

  if ($result === false) {
    // Handle the query execution error
    echo "Error executing the query: " . $conn->error;
  } else {
    if ($result->num_rows > 0) {
      // Display the appointment form with the doctor selection dropdown
      echo "<!DOCTYPE html>";
      echo "<html>";
      echo "<head>";
      echo "<title>Schedule Appointment</title>";
      echo "<style>";
      echo "body {";
      echo "  display: flex;";
      echo "  flex-direction: column;";
      echo "  align-items: center;";
      echo "  justify-content: center;";
      echo "  text-align: center;";
      echo "  padding-top: 50px;";
      echo "  background-color: #f2f2f2;";
      echo "  margin: 0;";
      echo "  font-family: Arial, sans-serif;";
      echo "}";
      echo "h1 {";
      echo "  color: #333;";
      echo "  margin-bottom: 30px;";
      echo "}";
      echo ".user-info {";
      echo "  font-size: 20px;";
      echo "  font-weight: bold;";
      echo "  margin-bottom: 20px;";
      echo "}";
      echo "form {";
      echo "  max-width: 400px;";
      echo "  padding: 20px;";
      echo "  background-color: #fff;";
      echo "  border-radius: 5px;";
      echo "  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);";
      echo "}";
      echo "label {";
      echo "  display: block;";
      echo "  margin-bottom: 8px;";
      echo "  color: #666;";
      echo "}";
      echo "input[type='date'],";
      echo "input[type='time'],";
      echo "input[type='text'],";
      echo "select {";
      echo "  width: 100%;";
      echo "  padding: 8px;";
      echo "  border: 1px solid #ccc;";
      echo "  border-radius: 4px;";
      echo "  margin-bottom: 12px;";
      echo "}";
      echo "input[type='submit'] {";
      echo "  background-color: #614caf;";
      echo "  color: white;";
      echo "  padding: 10px 20px;";
      echo "  font-size: 16px;";
      echo "  border: none;";
      echo "  border-radius: 4px;";
      echo "  cursor: pointer;";
      echo "}";
      echo "input[type='submit']:hover {";
      echo "  background-color: #5d45a0;";
      echo "}";
      echo "</style>";
      echo "</head>";
      echo "<body>";
      echo "<div class='user-info'>";
      echo "Welcome, $fullName!";
      echo "</div>";
      echo "<h1>Schedule Appointment</h1>";
      echo "<form method='POST' action='patient_appointment.php'>";
      echo "<label for='appointmentDate'>Date:</label>";
      echo "<input type='date' id='appointmentDate' name='appointmentDate' required><br>";
      echo "<label for='appointmentTime'>Time:</label>";
      echo "<input type='time' id='appointmentTime' name='appointmentTime' required><br>";
      echo "<label for='appointmentPurpose'>Purpose:</label>";
      echo "<input type='text' id='appointmentPurpose' name='appointmentPurpose' required><br>";
      echo "<label for='doctorSelection'>Select Doctor:</label>";
      echo "<select id='doctorSelection' name='doctorSelection'>";
      while ($row = $result->fetch_assoc()) {
        echo "<option value='" . $row['SSN'] . "'>" . $row['full_name'] . " - " . $row['specialization'] . "</option>";
      }
      echo "</select><br>";
      echo "<input type='submit' value='Schedule Appointment'>";
      echo "</form>";
      echo "<form method='POST' action='patient_view_appointments.php'>";
      echo "<input type='submit' value='View Appointments'>";
      echo "</form>";
      echo "<button><a href='patientpage.php'>Back</a></button>";
      echo "</body>";
      echo "</html>";
    } else {
      echo "No doctors available.";
    }
  }

  $conn->close();
} else {
  echo "Invalid session. Please login again.";
}
?>

