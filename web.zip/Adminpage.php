<?php
  // Start the session
  session_start();

  // Check if the 'full_name' key is set in the session
  if (isset($_SESSION['full_name'])) {
    // Retrieve the administrator's name from the session
    $adminName = $_SESSION['full_name'];
  }
?>

<!DOCTYPE html>
<html>
<head>
  <title>Administrator Page</title>
  <style>
    body {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      justify-content: center;
      text-align: center;
      padding-top: 150px;
      background-color: #f2f2f2;
      margin: 0;
      padding: 20px;
      font-family: Arial, sans-serif;
    }

    h1 {
      color: #333;
    }

    .button-container {
      align-self: flex-start;
      margin-top: 20px;
    }

    .button {
      display: block;
      padding: 10px 20px;
      font-size: 18px;
      background-color: #5b4caf;
      color: white;
      border: none;
      border-radius: 4px;
      text-decoration: none;
      margin-bottom: 10px;
      cursor: pointer;
    }

    .button:hover {
      background-color: #4b45a0;
    }
  </style>
</head>
<body>
  <?php if (isset($adminName)) { ?>
    <h1>Welcome, <?php echo $adminName; ?>!</h1>

    <div class="button-container">
      <a href="http://localhost/practicephp/admin_profile.php" class="button">Profile</a>
      <a href="http://localhost/practicephp/admin_view_users.php" class="button">View Users</a>
      <a href="http://localhost/practicephp/admin_manage_drugs.php" class="button">Drugs</a> 
      <a href="mainpage.html" class="button">Log Out</a>
    </div>
  <?php } ?>
</body>
</html>




