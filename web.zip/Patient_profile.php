<?php
require_once("connection.php");

// Start the session
session_start();

// Check if the 'email' key is set in the session
if (isset($_SESSION['email'])) {
  // Retrieve the patient's email from the session
  $email = $_SESSION['email'];

  // Retrieve the patient's details from the database
  $query = "SELECT * FROM patient WHERE email='$email'";
  $result = $conn->query($query);

  if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // Store the patient's full name in the session
    $_SESSION['full_name'] = $row['full_name'];

    // Retrieve the full name from the session
    $full_Name = $_SESSION['full_name'];

    // Welcome message
    echo "<div class='user-info'>";
    echo "Welcome, $full_Name!";
    echo "</div>";

    // Display the patient's profile details
    echo "<h1>Patient Profile</h1>";
    echo "<p>SSN: " . $row['SSN'] . "</p>";
    echo "<p>Full Name: " . $row['full_name'] . "</p>";
    echo "<p>Gender: " . $row['gender'] . "</p>";
    echo "<p>Email: " . $row['email'] . "</p>";
    echo "<p>Password: " . $row['PASSWORD'] . "</p>"; // Change 'password' to 'PASSWORD' if it's the actual column name
    echo "<p>Date of Birth: " . $row['date_of_birth'] . "</p>";
    echo "<p>Age: " . $row['age'] . "</p>";
    echo "<p>Phone Number: " . $row['phone_number'] . "</p>";
    echo "<p>Address: " . $row['address'] . "</p>";

    // Provide an option to edit the profile
    echo "<button class='edit-profile-button'><a href='Patient_edit.php'>Edit Profile</a></button>";

    // Add a "Back" button
    echo "<button class='back-button'><a href='Patientpage.php'>Back</a></button>";
  } else {
    echo "Patient not found.";
  }
} else {
  echo "Invalid session. Please login again.";
}

$conn->close();
?>

<style>
  .user-info {
  font-weight: bold;
  margin-bottom: 20px;
}

h1 {
  font-size: 24px;
  margin-bottom: 10px;
}

p {
  margin-bottom: 5px;
}

.edit-profile-button,
.back-button {
  display: inline-block;
  padding: 8px 16px;
  background-color: indigo; /* Updated color */
  color: white;
  text-decoration: none;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  margin-right: 10px;
}

.edit-profile-button a,
.back-button a {
  color: white;
  text-decoration: none;
}

</style>
