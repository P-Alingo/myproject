<?php
require_once("connect.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patientSSN = $_POST['ssn'];
    $newName = $_POST['name'];
    $newEmail = $_POST['email'];
    $newPassword = $_POST['password'];
    $newAddress = $_POST['address'];
    $newDateOfBirth = $_POST['dob'];
    
    // Perform edit operation using UPDATE statement
    $update_query = "UPDATE patient SET Name='$newName', Email='$newEmail', Password='$newPassword', Address='$newAddress', DateOfBirth='$newDateOfBirth' WHERE SSN='$patientSSN'";
    
    if ($conn->query($update_query) === TRUE) {
        echo "Patient record updated successfully.";
    } else {
        echo "Error updating patient record: " . $conn->error;
    }
} else {
    // Check if SSN parameter is present in the URL
    if (isset($_GET['ssn'])) {
        $patientSSN = $_GET['ssn'];

        // Fetch patient details by SSN
        $fetch_query = "SELECT * FROM patient WHERE SSN='$patientSSN'";
        $result = $conn->query($fetch_query);
        $row = $result->fetch_assoc();

        if ($row) {
            // Display form for editing patient details
            echo "
            <h2>Edit Patient Details</h2>
            <form action='' method='POST'>
                <input type='hidden' name='ssn' value='{$row['SSN']}' required>
                <label for='name'>Name:</label>
                <input type='text' name='name' value='{$row['Name']}' required><br>
                <label for='email'>Email:</label>
                <input type='email' name='email' value='{$row['Email']}' required><br>
                <label for='password'>Password:</label>
                <input type='password' name='password' value='{$row['Password']}' required><br>
                <label for='address'>Address:</label>
                <input type='text' name='address' value='{$row['Address']}' required><br>
                <label for='dob'>DateOfBirth:</label>
                <input type='date' name='dob' value='{$row['DateOfBirth']}'><br>
                <input type='submit' value='Update'>
            </form>
            ";
        } else {
            echo "Patient not found.";
        }
    } else {
        echo "Invalid request.";
    }
}

$conn->close();
?>