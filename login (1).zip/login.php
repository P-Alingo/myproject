<?php
session_start(); // Start the session

// Define the registered users and their corresponding passwords
$registeredUsers = [
    'admin' => 'admin123',
    'user' => 'user123'
];

// Get the submitted username and password
$username = $_POST['username'];
$password = $_POST['password'];

// Check if the username and password are valid
if (isset($registeredUsers[$username]) && $registeredUsers[$username] === $password) {
    // Valid credentials, set the user as logged in
    $_SESSION['username'] = $username;
    header("Location: username.php"); // Redirect to the welcome page
    exit();
} else {
    // Invalid credentials, redirect back to the login page
    header("Location: login.html?error=invalid");
    exit();
}
?>
