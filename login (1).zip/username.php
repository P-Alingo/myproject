<?php
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.html"); // Redirect to the login page if not logged in
    exit();
}

// Get the logged-in username
$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
</head>
<body>
    <h2>Welcome, <?php echo $username; ?>!</h2>
    <p>This is your personalized page.</p>
    <a href="logout.php">Logout</a> <!-- Add a logout link -->
</body>
</html>
